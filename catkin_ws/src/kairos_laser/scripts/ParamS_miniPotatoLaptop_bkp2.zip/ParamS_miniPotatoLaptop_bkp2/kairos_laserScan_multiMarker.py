#! /usr/bin/env python

#-------------------------------------------------------------------------------------------------
#   @file       : kairos_laserScan_multiMarker.py
#   @author     : PARAM D SALUNKHE | UTARI - AIS
#   @comments   : Each obstacle has a separate marker published
#-------------------------------------------------------------------------------------------------
  
#-------------------------------------------------------------------------------------------------
#   Package Imports
#-------------------------------------------------------------------------------------------------
 
import rospy
import itertools
import math
import numpy as np
import matplotlib.pyplot as plt
from sensor_msgs.msg import LaserScan
from visualization_msgs.msg import Marker
from geometry_msgs.msg import Point
 
 
#-------------------------------------------------------------------------------------------------
#   Global Variable Declarations
#-------------------------------------------------------------------------------------------------
 
front_minAngle = 0
front_maxAngle = 0
front_angIncrement = 0
front_rangeMin = 0
front_rangeMax = 0
front_ranges = []
front_FoV = 0
front_noOfScans = 0
scan_threshold_range = 5
marker_threshold_range = 2
ceiling_range = 10
obstacle_ranges = []
current_range_list = []
current_angle_list = []
range_lol = []
angle_lol = []
scan = LaserScan()
r0 = 0.2
 
 
#-------------------------------------------------------------------------------------------------
#   Plot Configurations
#-------------------------------------------------------------------------------------------------
 
plt.figure()
ax = plt.subplot(111, polar = True)
plt.ion()
 
 
#-------------------------------------------------------------------------------------------------
#   Function Definitions
#-------------------------------------------------------------------------------------------------
 
# ROS Callback function for the LaserScan subscriber
def frontScan_callback(scan_msg):
    global front_minAngle, front_maxAngle, front_angIncrement, front_FoV, front_noOfScans, front_rangeMin, front_rangeMax, front_ranges, obstacle_ranges
    front_minAngle = scan_msg.angle_min
    front_maxAngle = scan_msg.angle_max
    front_angIncrement = scan_msg.angle_increment
    front_FoV = front_maxAngle - front_minAngle
    front_noOfScans = (front_FoV + 1)/ front_angIncrement
    front_rangeMin = scan_msg.range_min
    front_rangeMax = scan_msg.range_max
    front_ranges = np.array(scan_msg.ranges)
    obstacle_ranges = [val for val in scan_msg.ranges if val < scan_threshold_range]
 
# For calculation of anglular position based on LaserScan ranges array index
def getAngle(range_index) -> float:
    global front_minAngle, front_angIncrement
    angle = front_minAngle + (range_index * front_angIncrement)
    return angle
 
# For processing the LaserScan ranges to obtain the array of lists containing obstacle features and it's angular position
def processRangeData(ranges):
    global scan_threshold_range, ceiling_range, current_range_list, current_angle_list, range_lol, angle_lol
    current_range_list = []
    current_angle_list = []
    range_lol = []
    angle_lol = []
 
    for i, value in enumerate(ranges):
        if (value < scan_threshold_range):
            if (not current_range_list):
                if (i > 0):
                    current_range_list.append(ranges[i-1])
                    current_angle_list.append(getAngle(i-1))
            current_range_list.append(value)
            current_angle_list.append(getAngle(i))
        else:
            if current_range_list:
                if i < len(ranges):
                    current_range_list.append(value)
                    current_angle_list.append(getAngle(i))
                range_lol.append(current_range_list)
                angle_lol.append(current_angle_list)
                current_range_list = []
                current_angle_list = []
 
    if current_range_list:
        if i < (len(ranges)-1):
            current_range_list.append(ranges[i])
            current_angle_list.append(getAngle(i))
        range_lol.append(current_range_list)
        angle_lol.append(current_angle_list)
 
# For displaying LIDAR specifications
def displayLaserSpecs():
        rospy.loginfo("*** KAIROS+ Front Laser Specifications *** \n")
        rospy.loginfo("Minimum Angle in degrees: %f \n", front_minAngle)
        rospy.loginfo("Maximum Angle in degrees: %f \n", front_maxAngle)
        rospy.loginfo("Angle increment in degrees: %f \n", front_angIncrement)
        rospy.loginfo("FoV in degrees: %f \n", front_FoV)
        rospy.loginfo("Number of scans per sweep: %f \n", front_noOfScans)
        rospy.loginfo("Min Range scanned in m: %f \n", front_rangeMin)
        rospy.loginfo("Max Range scanned in m %f \n", front_rangeMax)
        rospy.loginfo("Range array size: %d \n", len(front_ranges))
        rospy.loginfo("***   ***   ***\n")
 
# For displaying the polar plot of LaserScan ranges
def displayPolarPlot():
    plot_r = np.concatenate(range_lol)
    plot_theta = np.concatenate(angle_lol)
    ax.clear()
    ax.plot(plot_theta, plot_r, marker = 'o')
    plt.title('KAIROS+ Front Laser data')
    plt.pause(0.01)
 
# For a Publisher node to receive data generated by this Subscriber node (called by Publisher)
# def getSubscriberData():
#    return range_list_array, angle_list_array
 
# ROS Publisher function to publish customized laserScan data (to be coded into a separate .py file)
def publish_laserScan(pub):
    if len(range_lol) == 0:
        rospy.logerr("Scan ranges array input to the publisher is empty!")
    if len(angle_lol) == 0:
        rospy.logerr("Scan angles array input to the publisher is empty!")
 
    scan = LaserScan()
    scan.header.frame_id = 'robot_front_laser_link'
    scan.angle_min = front_minAngle
    scan.angle_max = front_maxAngle
    scan.angle_increment = front_angIncrement
    scan.range_min = front_rangeMin
    scan.range_max = front_rangeMax
    scan_range_list = list(itertools.chain.from_iterable(range_lol))
    scan.ranges = [float(num) for num in scan_range_list]
    scan.header.stamp = rospy.Time.now()
    pub.publish(scan)

# For computing the centroid an of obstacle marker published in RViz
def compute_centroid(points):
    sum_x = sum(point.x for point in points)
    sum_y = sum(point.y for point in points)
    n = len(points)
    g_x = (1/n) * sum_x
    g_y = (1/n) * sum_y
    return Point(g_x, g_y, 0)

# ROS Publisher function to publish the centroid of an obstacle marker
def publish_centroid(centroid, pub):
    centroid_marker = Marker()
    centroid_marker.header.frame_id = "robot_front_laser_link"
    centroid_marker.type = Marker.CYLINDER
    centroid_marker.scale.x = 0.05
    centroid_marker.scale.y = 0.05
    centroid_marker.scale.z = 0.01
    centroid_marker.color.r = 0.0
    centroid_marker.color.g = 1.0
    centroid_marker.color.b = 0.0
    centroid_marker.color.a = 1.0
    centroid_marker.pose.position = centroid
    centroid_marker.pose.orientation.x = 0.0
    centroid_marker.pose.orientation.y = 0.0
    centroid_marker.pose.orientation.z = 0.0
    centroid_marker.pose.orientation.w = 1.0
    centroid_marker.header.stamp = rospy.Time.now()
    centroid_marker.lifetime = rospy.Duration(0.1)
    pub.publish(centroid_marker)

# ROS Publisher function to publish the region of influence (ROI) padding over about the obstacle
def publish_roi(points, centroid, pub):
    global r0
    roi_marker = Marker()
    roi_marker.header.frame_id = "robot_front_laser_link"
    roi_marker.type = Marker.LINE_STRIP
    roi_marker.scale.x = 0.05
    roi_marker.color.r = 0.0
    roi_marker.color.g = 1.0
    roi_marker.color.b = 1.0
    roi_marker.color.a = 1.0
    roi_marker.pose.orientation.x = 0.0
    roi_marker.pose.orientation.y = 0.0
    roi_marker.pose.orientation.z = 0.0
    roi_marker.pose.orientation.w = 1.0
    roi_marker.points = []

    for point in points:
        dir_x = point.x - centroid.x
        dir_y = point.y - centroid.y
        length = math.sqrt(dir_x**2 + dir_y**2)
        unit_x = dir_x / length
        unit_y = dir_y / length
        roi_x = point.x + (unit_x * r0)
        roi_y = point.y + (unit_y * r0)
        roi_point = Point(roi_x, roi_y, 0)
        roi_marker.points.append(roi_point)
    roi_marker.header.stamp = rospy.Time.now()
    roi_marker.lifetime = rospy.Duration(0.1)
    pub.publish(roi_marker)

 
# ROS Publisher function to publish Marker line strips on thresholded obstacles (to be coded into a separate .py file)
def publish_markers(pub):
    marker_range_list = list(itertools.chain.from_iterable(range_lol))
    marker_angle_list = list(itertools.chain.from_iterable(angle_lol))
    #markers = []
    u = 0
    for j in range(len(marker_range_list)):
        #print(f"scan range number: {j}")
        markers = Marker()
        markers.header.frame_id = 'robot_front_laser_link'
        markers.ns = 'thresholded_laserScan'
        markers.id = j                               # Should it be equal to i ?
        markers.type = Marker.LINE_STRIP
        markers.action = Marker.ADD
        markers.pose.orientation.w = 1.0
        markers.scale.x = 0.02
        markers.color.r = 1.0
        markers.color.g = 0.0
        markers.color.b = 0.0
        markers.color.a = 1.0
        markers.pose.orientation.x = 0.0
        markers.pose.orientation.y = 0.0
        markers.pose.orientation.z = 0.0
        markers.pose.orientation.w = 1.0
        points = []
        while (marker_range_list[j] < marker_threshold_range):
            '''if (not points) and (j > 0):
                r = marker_angle_list[j-1]
                theta = marker_angle_list[j-1]
                prefix_point = Point()
                prefix_point.x = r * np.cos(theta)
                prefix_point.y = r * np.sin(theta)
                prefix_point.z = 0.0
                points.append(prefix_point)'''
            r = marker_range_list[j]
            theta = marker_angle_list[j]
            marker_point = Point()
            marker_point.x  = r * np.cos(theta)
            marker_point.y = r * np.sin(theta)
            marker_point.z = 0.0
            points.append(marker_point)
            markers.points = points
            if(j < len(marker_range_list)-1):
                j += 1
            else:
                j = 0
        if points:
            print(f"obstacle number: {u}")
            markers.header.stamp = rospy.Time.now()
            markers.lifetime = rospy.Duration(0.1)
            pub.publish(markers)
            u += 1
            centroid = compute_centroid(points)
            publish_centroid(centroid, centroid_pub)
            publish_roi(points, centroid, roi_pub)
    u = 0


#-------------------------------------------------------------------------------------------------
#   Main Function
#-------------------------------------------------------------------------------------------------
 
if __name__ == '__main__':
    try:
        rospy.init_node('laserScan_subscriber_node', anonymous=True)                                # Initializing a ROS node
        rospy.Subscriber('robot/front_laser/scan_filtered', LaserScan, frontScan_callback)          # Registering a subscriber to LaserScan message
 
        #rospy.init_node('laserScan_publisher_node', anonymous=True)                                # Only one node creation is allowed
        scan_pub = rospy.Publisher('/processed_laserScan', LaserScan, queue_size=10)
        marker_pub = rospy.Publisher('/obstacle_marker', Marker, queue_size=10)
        centroid_pub = rospy.Publisher('/centroid_marker', Marker, queue_size=10)
        roi_pub = rospy.Publisher('/ROI_marker', Marker, queue_size=10)
        
 
        displayLaserSpecs()
 
        loopRate = rospy.Rate(50)                                                                   # Loop rate frequency (1 Hz)
        while not rospy.is_shutdown():
            print(f"Sub-threshold Obstacle range array size: {len(obstacle_ranges)} \n")            # Using print() instead of rospy.loginfo() To avoid overcrowding ros logs (?)
            processRangeData(front_ranges)
            displayPolarPlot()
            publish_laserScan(scan_pub)                                                             # To publish the processed laserScan message
            publish_markers(marker_pub)                                                             # To publish a marker message over a thresholded laserScan data
            print("***   ***   ***\n")
            loopRate.sleep()                                                                        # Sleep for the reqd. amount of time to maintain the loop rate frequency
    except rospy.ROSInterruptException:
        rospy.logerr("*** ERROR *** \n")
        pass
