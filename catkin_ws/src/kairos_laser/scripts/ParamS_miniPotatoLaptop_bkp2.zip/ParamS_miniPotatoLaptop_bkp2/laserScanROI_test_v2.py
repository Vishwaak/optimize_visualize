#! /usr/bin/env python

#-------------------------------------------------------------------------------------------------
#   @file       : test_laserScan_v2.py
#   @author     : PARAM D SALUNKHE | UTARI - AIS
#   @comments   : Implementation of ROI for artificial potential fields using LaserScan messages
#   @issue      : Need a different ROI generation logic for non-convex obstacles.
#-------------------------------------------------------------------------------------------------
 
#-------------------------------------------------------------------------------------------------
#   Package Imports
#-------------------------------------------------------------------------------------------------
 
import rospy
import math
import numpy as np
from sensor_msgs.msg import LaserScan
from visualization_msgs.msg import Marker, MarkerArray
from geometry_msgs.msg import Point
 
#-------------------------------------------------------------------------------------------------
#   Global Variable Declarations
#-------------------------------------------------------------------------------------------------

#-------------------------------------------------------------------------------------------------
#   Class Definitions
#-------------------------------------------------------------------------------------------------

class laserScanProcessor:
    def __init__(self):
        rospy.init_node('laserScan_subscriber_node', anonymous=True)                             # Initializing a ROS node
        self.marker_pub = rospy.Publisher('/obstacle_marker', Marker, queue_size=10)             # Creating a ROS Publisher for publishing obstacle boundaries
        self.centroid_pub = rospy.Publisher('/centroid_marker', Marker, queue_size=10)           # Creating a ROS Publisher for publishing obstacle centroids
        self.scan_pub = rospy.Publisher('/ROI_laserScan', LaserScan, queue_size=10)              # Creating a ROS Publisher for processed ROI LaserScan messages
        self.repForce_pub = rospy.Publisher('/rep_marker', MarkerArray, queue_size=10)           # Creating a ROS Publisher for publishing obstacle Repulsive force arrow marker
        self.front_minAngle = 0                             # unit: radian
        self.front_maxAngle = 0                             # unit: radian
        self.front_angIncrement = 0                         # unit: radian
        self.front_minRange = 0                             # unit: meters
        self.front_maxRange = 0                             # unit: meters 
        self.front_ranges = []                              # unit: meters
        self.front_FoV = 0                                  # unit: count
        self.front_noOfScans = 0                            # unit: meters
        self.scan_threshold_range = 5                       # unit: meters
        self.marker_threshold_range = 2.0                   # unit: meters
        self.r0 = 1.0                                       # unit: meters
        self.loop_frequency = 250                           # unit: hertz
        self.marker_lifetime = 1/self.loop_frequency        # uint: seconds
        self.k_rep = 0.2                                    # unit: repulsive field constant
        self.roi_ranges = []                                # Holds the LaserScan ranges[] for the ROI of all sub-threshold obstacles captured in one LIDAR scan. Re-initialized in publish_obstacles()
        self.scan = LaserScan()                             # LaserScan object used for publishing the ROI
        self.centroids = []                                 # List of centroids of obstacles detected in a single LIDAR scan


    # ROS Callback function for the LaserScan subscriber
    def frontScan_callback(self, scan_msg):                                         
        self.front_minAngle = scan_msg.angle_min
        self.front_maxAngle = scan_msg.angle_max
        self. front_angIncrement = scan_msg.angle_increment
        self.front_FoV = self.front_maxAngle - self.front_minAngle
        self.front_noOfScans = (self.front_FoV + 1)/ self.front_angIncrement
        self.front_minRange = scan_msg.range_min
        self.front_maxRange = scan_msg.range_max
        self.front_ranges = scan_msg.ranges
            
    # For calculation of angular position based on LaserScan ranges array index
    def getAngle(self, range_index) -> float:
        angle = self.front_minAngle + (range_index * self.front_angIncrement)
        return angle
    
    # For displaying LIDAR specifications
    def displayLaserSpecs(self):
        rospy.loginfo("*** KAIROS+ Front Laser Specifications *** \n")
        rospy.loginfo("Minimum Angle in degrees: %f \n", self.front_minAngle)
        rospy.loginfo("Maximum Angle in degrees: %f \n", self.front_maxAngle)
        rospy.loginfo("Angle increment in degrees: %f \n", self.front_angIncrement)
        rospy.loginfo("FoV in degrees: %f \n", self.front_FoV)
        rospy.loginfo("Number of scans per sweep: %f \n", self.front_noOfScans)
        rospy.loginfo("Min Range scanned in m: %f \n", self.front_minRange)
        rospy.loginfo("Max Range scanned in m %f \n", self.front_maxRange)
        rospy.loginfo("Range array size: %d \n", len(self.front_ranges))
        rospy.loginfo("***   ***   ***\n")
        
    # For computing the centroid an of obstacle marker published in RViz
    def compute_centroid(self, points):
        sum_x = sum(point.x for point in points)
        sum_y = sum(point.y for point in points)
        n = len(points)
        g_x = (1/n) * sum_x                                                 # Centroid x-coordinate
        g_y = (1/n) * sum_y                                                 # Centroid y-coordinate
        print(f"g_x = {g_x}")
        print(f"g_y = {g_y}")
        self.centroids.append(Point(g_x, g_y, 0))
        return Point(g_x, g_y, 0)
    
    # ROS Publisher function to publish the centroids of obstacle markers
    def publish_centroids(self):
        centroid_marker = Marker()
        centroid_marker.header.frame_id = "robot_front_laser_link"         # Populating the necessary fields for the Marker message
        centroid_marker.type = Marker.POINTS
        centroid_marker.scale.x = 0.05
        centroid_marker.scale.y = 0.05
        centroid_marker.color.r = 0.0
        centroid_marker.color.g = 1.0
        centroid_marker.color.b = 0.0
        centroid_marker.color.a = 1.0
        centroid_marker.points = self.centroids
        centroid_marker.pose.orientation.w = 1.0
        centroid_marker.header.stamp = rospy.Time.now()
        centroid_marker.lifetime = rospy.Duration(self.marker_lifetime)
        self.centroid_pub.publish(centroid_marker)
    
    # ROS Publsiher function to publish arrows that indicate the repulsive forces exerted on the robot by obstacles
    def publish_potentialFields(self):
        rep_markerArray = MarkerArray()
        for i, centroid in enumerate(self.centroids):
            distance_rxy = math.sqrt(centroid.x**2 + centroid.y**2)
            if distance_rxy <= 0.3:                                         # Setting a minimum threshold of 0.3m for r(xy)
                distance_rxy = 0.3
            rep_unit_x = -centroid.x / distance_rxy                         # Calculating unit vector for the repulsive force
            rep_unit_y = -centroid.y / distance_rxy

            # formula for x- and y- gradient of the repulsive potential field of the obstacle
            if (distance_rxy <= self.r0):
                rep_x = centroid.x + (rep_unit_x * (self.k_rep / (distance_rxy**2)) * ((1 / distance_rxy) - (1 / self.r0)))
                rep_y = centroid.y + (rep_unit_y * (self.k_rep / (distance_rxy**2)) * ((1 / distance_rxy) - (1 / self.r0)))
            else:
                rep_x = centroid.x                                          # The robot should not experience any repulsion if it is outside the ROI
                rep_y = centroid.y
            rep_point = Point(rep_x, rep_y, 0)

            rep_marker = Marker()
            rep_marker.header.frame_id = "robot_front_laser_link"           # Populating the necessary fields for the Marker message
            rep_marker.type = Marker.ARROW
            rep_marker.id = i
            rep_marker.ns = 'repulsive_forces'
            rep_marker.scale.x = 0.05
            rep_marker.scale.y = 0.1
            rep_marker.scale.z = 0.15
            rep_marker.color.r = 0.8
            rep_marker.color.g = 0.2
            rep_marker.color.b = 0.8
            rep_marker.color.a = 1.0
            rep_marker.pose.orientation.w = 1.0
            rep_marker.points.append(centroid)
            rep_marker.points.append(rep_point)
            rep_marker.header.stamp = rospy.Time.now()
            rep_marker.lifetime = rospy.Duration(self.marker_lifetime)
            rep_markerArray.markers.append(rep_marker)                      # Adding the ARROW marker to the MarkerArray
        self.repForce_pub.publish(rep_markerArray)

    # For computing the Region of Influence (roi_ranges[]) of the obstacle based on it's convex hull 
    def compute_roi(self, points, centroid):
        for point in points:
            dir_x = point.x - centroid.x                                    # Generating direction vector from the centroid g to the obstacle point p (dir = p - g)
            dir_y = point.y - centroid.y
            length = math.sqrt(dir_x**2 + dir_y**2)                         # Computing magnitude or norm of the direction vector (||dir||)
            unit_x = dir_x / length                                         # Generating unit vector of dir (u = dir / ||dir||)
            unit_y = dir_y / length
            roi_x = point.x + (unit_x * self.r0)                            # Generating a vector of constant magnitude r0 and direction same as u (u.r0) that starts--
            roi_y = point.y + (unit_y * self.r0)                            # --from the obstacle point. The end point will be the ROI point for the obstacle point.

            roi_r = math.sqrt(roi_x**2 + roi_y**2)                          # Converting coordinates: Cartesian form (x,y) -> Polar form (r,theta)  
            roi_theta =  math.atan2(roi_y, roi_x)
            if (self.front_minAngle <= roi_theta <= self.front_maxAngle):
                index = int((roi_theta - self.front_minAngle)/self.front_angIncrement)
                self.roi_ranges[index] = roi_r                              # roi_ranges[] will have the value equal to polar "r" of the ROI point,--
                                                                            # --at index which depends on polar "theta" of the ROI point.
    
    # ROS Publisher function to publish a region of influence (ROI) padding over all the thresholded obstacles using a LaserScan message
    def publish_roi(self): 
        scan = LaserScan()                                 
        scan.header.frame_id = 'robot_front_laser_link'                     # Populating the necessary fields for the LaserScan message
        scan.angle_min = self.front_minAngle
        scan.angle_max = self.front_maxAngle
        scan.angle_increment = self.front_angIncrement
        scan.range_min = self.front_minRange
        scan.range_max = self.front_maxRange
        scan.ranges = self.roi_ranges                                       # ranges[] = roi_ranges[]
        scan.header.stamp = rospy.Time.now()
        self.scan_pub.publish(scan)
        
    # ROS Publisher function to publish Marker line strips on thresholded obstacles (to be coded into a separate .py file)
    def publish_obstacles(self):
        self.roi_ranges = [5.5] * len(self.front_ranges)                    # This list will hold the laserScan ranges[] for the ROI of all obstacles captured in one LIDAR scan
                                                                            # Re-initialize all elements of roi_ranges[] with the ceiling value for the next LIDAR scan                                               
        points = []                                                         # This list will hold the set of points that form a sub-threshold obstacle
        markerNumber = 0                                                    
        for j in range(len(self.front_ranges)):                             # :: LOOP START :: For each ranges element in the subscribed LaserScan message -- 
            if self.front_ranges[j] < self.marker_threshold_range:          # -- CONDITION: is range element sub-threshold? 
                r = self.front_ranges[j]                                    #  - TRUE: -- convert element coordinates from Polar to Cartesian
                theta = self.getAngle(j)                                    #          -- add cartesian point to points[]
                marker_point = Point()
                marker_point.x = r * np.cos(theta)
                marker_point.y = r * np.sin(theta)
                marker_point.z = 0.0
                points.append(marker_point)
            else:                                                           # - FALSE: --
                self.roi_ranges.append(5.5)                                 #          -- set all non-subthreshold range values to a ceiling of 5.5m 
                if points:                                                  #          -- CONDITION: are we on the first range element in the subscribed message?
                    marker = Marker()                                       #           - FALSE: -- populate necessary fields for the Marker message
                    marker.header.frame_id = 'robot_front_laser_link'       #                    -- publish /obstacle_marker for points[]
                    marker.ns = 'thresholded_laserScan'                     #                    -- compute the centroid
                    marker.id = markerNumber                                #                    -- compute the obstacle ROI points to be added to roi_ranges[]
                    print(f"obstacle #{marker.id} @inner if loop")          #                    -- make points[] empty again for  capturing the next obstacle
                    marker.type = Marker.LINE_STRIP                         #           - TRUE: -- do nothing
                    marker.action = Marker.ADD                              # :: LOOP END ::               
                    marker.scale.x = 0.02
                    marker.color.r = 1.0
                    marker.color.g = 0.0
                    marker.color.b = 0.0
                    marker.color.a = 1.0
                    marker.pose.orientation.x = 0.0
                    marker.pose.orientation.y = 0.0
                    marker.pose.orientation.z = 0.0
                    marker.pose.orientation.w = 1.0
                    marker.points = points
                    marker.header.stamp = rospy.Time.now()
                    marker.lifetime = rospy.Duration(self.marker_lifetime)
                    self.marker_pub.publish(marker)
                    centroid = self.compute_centroid(points)
                    self.compute_roi(points, centroid)
                    points = []
                    markerNumber += 1
        if points:                                                          # -- CONDITION: is points[] still not empty? => need to publish markers for this points[]
            centroid = self.compute_centroid(points)                        #  - TRUE:  -- populate necessary fields for the Marker message
            self.compute_roi(points, centroid)                              #           -- publish /obstacle_marker for points[] 
            marker = Marker()                                               #           -- compute the centroid
            marker.header.frame_id = 'robot_front_laser_link'               #           -- compute obstacle ROI points to be added to roi_ranges[]
            marker.ns = 'thresholded_laserScan'                             #  - FALSE: -- do nothing
            marker.id = markerNumber
            print(f"obstacle #{marker.id} @outer if loop")
            marker.type = Marker.LINE_STRIP
            marker.action = Marker.ADD
            marker.scale.x = 0.02
            marker.color.r = 1.0
            marker.color.g = 0.0
            marker.color.b = 0.0
            marker.color.a = 1.0
            marker.pose.orientation.x = 0.0
            marker.pose.orientation.y = 0.0
            marker.pose.orientation.z = 0.0
            marker.pose.orientation.w = 1.0
            marker.points = points
            marker.header.stamp = rospy.Time.now()
            marker.lifetime = rospy.Duration(self.marker_lifetime)
            self.marker_pub.publish(marker)
        markerNumber = 0                                                    # Re-initialize obstacle count to 0

#-------------------------------------------------------------------------------------------------
#   Function Definitions
#-------------------------------------------------------------------------------------------------


#-------------------------------------------------------------------------------------------------
#   Main Function
#-------------------------------------------------------------------------------------------------
 
if __name__ == '__main__':
    try:
        processor = laserScanProcessor()
        rospy.Subscriber('/robot/front_laser/scan_filtered', LaserScan, processor.frontScan_callback)
        processor.displayLaserSpecs()
        loopRate = rospy.Rate(processor.loop_frequency)                     # Loop rate frequency (25 Hz)
        while not rospy.is_shutdown():
            processor.publish_obstacles()                                   # To publish obstacle markers over a thresholded laserScan data
            processor.publish_centroids()                                   # To publish the centroids of the visible thresholded obstacles
            processor.publish_roi()                                         # One LIDAR Scan complete. Publish ROI for obstacles captured in this scan
            processor.publish_potentialFields()                             # Publish ARROW markers representing the replusive force exerted by obstacle potential fields
            processor.centroids = []                                        # Re-initialize the centroids[] list to "empty" for the next LIDAR scan
            print("***   ***   ***\n")
            loopRate.sleep()                                                # Sleep for the reqd. amount of time to maintain the loop rate frequency
    except rospy.ROSInterruptException:
        rospy.logerr("*** ERROR *** \n")
        pass
